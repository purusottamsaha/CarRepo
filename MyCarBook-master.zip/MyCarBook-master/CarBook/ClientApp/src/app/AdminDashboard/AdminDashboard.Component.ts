import { Component } from '@angular/core';
import { NgProgressService } from "ng2-progressbar";
import { Router } from '@angular/router'

@Component({
  templateUrl: './AdminDashboard/AdminDashboard.html',
  styleUrls: ['../../css/Dashboard.css']
})
export class AdminDashboardComponent {

}
