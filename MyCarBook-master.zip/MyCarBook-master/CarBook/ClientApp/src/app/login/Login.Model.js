"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LoginModel = /** @class */ (function () {
    function LoginModel() {
        this.Username = "";
        this.Password = "";
    }
    return LoginModel;
}());
exports.LoginModel = LoginModel;
//# sourceMappingURL=Login.Model.js.map