import { Component, OnInit } from '@angular/core';
import { LoginService } from './Services/Login.Service';
import { Router } from '@angular/router';
import { NgProgressService } from "ng2-progressbar";
import { LoginModel } from './Login.Model';

@Component({
  
  templateUrl: './login.component.html',
  //styleUrls: ['./login.component.css']
  styleUrls: ['../../css/Login.css'],
  providers: [LoginService]
})
export class LoginComponent  {

  constructor( private _Route: Router, private _LoginService: LoginService) {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('AdminUser');
  }
  onSubmit() {
    //this.pService.start();

    var loginmodel = this.LoginModel;

    this._LoginService.validateLoginUser(this.LoginModel).subscribe
      (
        data => {
          this.webresponse = data;

          if (this.webresponse.UserTypeID == "0") {
            alert("Invalid Username and Password");
            this._Route.navigate(['Login']);
          }
          else {
            if (this.webresponse.UserTypeID == "2") {
              alert("Logged in Successfully");
              this._Route.navigate(['UserDashboard']);
            }
            else {
              alert("Logged in Successfully");
              this._Route.navigate(['AdminDashboard']);
            }
          }
        },
        err => {
          if (err) {
            alert("An Error has occured please try again after some time !");
          }
        });


    //this.pService.done();
  }
  LoginModel: LoginModel = new LoginModel();
  webresponse: any;
  status: boolean;
  

}
